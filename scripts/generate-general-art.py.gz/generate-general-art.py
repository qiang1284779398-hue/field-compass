from pathlib import Path
import html

ROOT=Path.cwd()
OUT=ROOT/'game-assets'/'generated-previews'
OUT.mkdir(parents=True, exist_ok=True)
heroes=[
 dict(id='zhao',slug='zhao-yun',name='赵云',title='常胜将军',role='银甲白袍·龙胆枪',main='#dce8e8',mid='#7699a5',dark='#263c4d',light='#f5f1dc',gold='#c5a66a',cloth='#557f92',skin='#e5b28d',hair='#17232c',beard='none',helm='plume',weapon='spear',motif='dragon',kind='warrior',accent='#8fc5d3'),
 dict(id='zhuge',slug='zhuge-liang',name='诸葛亮',title='卧龙先生',role='鹤氅纶巾·羽扇',main='#d9d0ad',mid='#8a9c86',dark='#293f42',light='#f5edcf',gold='#b8995e',cloth='#6c897f',skin='#e8bd99',hair='#20252a',beard='long',helm='scholar',weapon='fan',motif='eight',kind='scholar',accent='#b9d6c2'),
 dict(id='huang',slug='huang-zhong',name='黄忠',title='老当益壮',role='金甲老将·百步弓',main='#b68a42',mid='#596d46',dark='#292e28',light='#efcf83',gold='#d0ad62',cloth='#435a3b',skin='#bd805d',hair='#d4d0c4',beard='grey',helm='veteran',weapon='bow',motif='sun',kind='veteran',accent='#e2b86d'),
 dict(id='dia',slug='diaochan',name='貂蝉',title='闭月',role='绛紫霓裳·月影双刃',main='#9d719d',mid='#5d405f',dark='#2b263e',light='#f2d8df',gold='#d7b77b',cloth='#9d6283',skin='#f0c5ae',hair='#171927',beard='none',helm='hairpin',weapon='ribbon',motif='moon',kind='female',accent='#dca6d2'),
 dict(id='cao',slug='cao-cao',name='曹操',title='魏武帝',role='玄甲赤氅·倚天剑',main='#4b526f',mid='#30344a',dark='#171c2c',light='#bfc6d6',gold='#c6a45f',cloth='#4a3348',skin='#d9a17c',hair='#171b23',beard='short',helm='crown',weapon='sword',motif='eagle',kind='commander',accent='#9e5660'),
 dict(id='zhou',slug='zhou-yu',name='周瑜',title='美周郎',role='赤金儒将·古锭剑',main='#a94736',mid='#6f2c2d',dark='#341e2a',light='#f5d9a0',gold='#d7b36e',cloth='#a34b3b',skin='#e7b18d',hair='#211c20',beard='fine',helm='phoenix',weapon='sword',motif='flame',kind='commander',accent='#e6a75a'),
 dict(id='lvbu',slug='lv-bu',name='吕布',title='人中吕布',role='赤焰重铠·方天画戟',main='#9d332f',mid='#55252d',dark='#211b27',light='#e3b98b',gold='#c8a05a',cloth='#672d32',skin='#d59a79',hair='#151820',beard='none',helm='wings',weapon='halberd',motif='beast',kind='brute',accent='#e16b4e'),
 dict(id='diaowei',slug='dian-wei',name='典韦',title='古之恶来',role='铜铁重甲·双戟',main='#7e5d43',mid='#45413b',dark='#201f22',light='#c8a36d',gold='#b9975e',cloth='#6a292e',skin='#c38a68',hair='#14191b',beard='wild',helm='bare',weapon='axes',motif='tiger',kind='brute',accent='#b65b42'),
 dict(id='jiang',slug='jiang-wei',name='姜维',title='幼麟',role='青银轻铠·麒麟枪',main='#78a9b0',mid='#3c6879',dark='#203b50',light='#e6e4cd',gold='#c6ab70',cloth='#496d7e',skin='#e0ae89',hair='#1c2831',beard='none',helm='crest',weapon='spear',motif='kylin',kind='warrior',accent='#9bcfca'),
]

def defs(h):
    return f'''<defs>
 <linearGradient id="armor" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{h['light']}"/><stop offset=".18" stop-color="{h['main']}"/><stop offset=".55" stop-color="{h['mid']}"/><stop offset="1" stop-color="{h['dark']}"/></linearGradient>
 <linearGradient id="cloth" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{h['accent']}"/><stop offset=".28" stop-color="{h['cloth']}"/><stop offset=".72" stop-color="{h['mid']}"/><stop offset="1" stop-color="{h['dark']}"/></linearGradient>
 <linearGradient id="metal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff4d6"/><stop offset=".2" stop-color="{h['light']}"/><stop offset=".52" stop-color="{h['gold']}"/><stop offset=".82" stop-color="#76502b"/><stop offset="1" stop-color="#30271f"/></linearGradient>
 <linearGradient id="skin" x1="0" y1="0" x2=".8" y2="1"><stop stop-color="#ffe0bd"/><stop offset=".42" stop-color="{h['skin']}"/><stop offset="1" stop-color="#8e5744"/></linearGradient>
 <linearGradient id="hair" x1="0" y1="0" x2="1" y2="0"><stop stop-color="{h['hair']}"/><stop offset=".5" stop-color="#39404a"/><stop offset="1" stop-color="#0b1017"/></linearGradient>
 <linearGradient id="cape" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{h['accent']}"/><stop offset=".45" stop-color="{h['cloth']}"/><stop offset="1" stop-color="{h['dark']}"/></linearGradient>
 <linearGradient id="blade" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fffdf0"/><stop offset=".22" stop-color="#c8d4d0"/><stop offset=".55" stop-color="#6e8586"/><stop offset=".8" stop-color="#e6dfc8"/><stop offset="1" stop-color="#35474c"/></linearGradient>
 <pattern id="scales" width="26" height="20" patternUnits="userSpaceOnUse"><path d="M1 1 Q13 16 25 1" fill="none" stroke="{h['gold']}" stroke-width="2" opacity=".7"/></pattern>
 <pattern id="brocade" width="42" height="42" patternUnits="userSpaceOnUse"><path d="M21 3 L36 21 L21 39 L6 21Z" fill="none" stroke="{h['light']}" stroke-width="2" opacity=".4"/><circle cx="21" cy="21" r="4" fill="{h['gold']}" opacity=".55"/></pattern>
 <filter id="shadow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="8"/></filter>
 </defs>'''

def weapon(h):
    w=h['weapon']
    if w=='spear':
        return '''<g><path d="M154 921 L255 122" stroke="#201d1b" stroke-width="24" stroke-linecap="round"/><path d="M154 921 L255 122" stroke="#9b7443" stroke-width="13"/><path d="M154 921 L255 122" stroke="#f1dca5" stroke-width="3"/><path d="M220 234 Q169 165 225 65 Q257 27 296 12 Q289 82 327 121 Q300 194 220 234Z" fill="url(#blade)" stroke="#344b51" stroke-width="9"/><path d="M226 207 Q227 108 296 12 Q284 113 247 193Z" fill="#fff9df" opacity=".65"/><path d="M195 247 Q245 274 294 244 L306 279 Q247 318 180 283Z" fill="url(#metal)" stroke="#634b2c" stroke-width="6"/></g>'''
    if w=='fan':
        return '''<g><path d="M655 715 L705 500" stroke="#493624" stroke-width="18" stroke-linecap="round"/><path d="M655 715 Q527 540 614 445 Q703 433 741 535 Q738 634 655 715Z" fill="#e9e0c8" stroke="#765f43" stroke-width="9"/><path d="M655 715 L614 445 M655 715 L646 438 M655 715 L679 444 M655 715 L712 468 M655 715 L739 534" stroke="#9c865c" stroke-width="5"/><path d="M617 510 Q678 540 724 587" fill="none" stroke="#b5a27d" stroke-width="3"/><path d="M640 684 Q657 698 673 681" fill="none" stroke="#d3ae67" stroke-width="6"/></g>'''
    if w=='bow':
        return '''<g><path d="M672 205 Q793 421 665 715" fill="none" stroke="#6b472b" stroke-width="18"/><path d="M672 205 Q704 455 665 715" fill="none" stroke="#d7b56e" stroke-width="5"/><path d="M672 205 L665 715" stroke="#d8d2ba" stroke-width="3"/><path d="M623 287 L690 214 L699 231 L638 304Z M632 324 L705 251 L714 269 L646 342Z M640 361 L721 286 L729 304 L653 379Z" fill="#776044" stroke="#d0ad69" stroke-width="4"/></g>'''
    if w=='ribbon':
        return '''<g fill="none" stroke-linecap="round"><path d="M607 536 Q756 432 722 298 Q696 208 763 136" stroke="#e7bad6" stroke-width="16"/><path d="M620 555 Q766 515 760 393 Q757 321 789 275" stroke="#a77aab" stroke-width="10"/><path d="M239 584 Q97 501 104 390 Q114 303 53 238" stroke="#f2d6e0" stroke-width="13"/><path d="M245 611 Q109 576 87 487" stroke="#d7a7c8" stroke-width="7"/></g><g><path d="M668 717 L748 542" stroke="#4c3547" stroke-width="13"/><path d="M748 542 Q794 508 776 468 Q746 482 726 510Z" fill="url(#blade)" stroke="#806348" stroke-width="5"/><path d="M228 732 L142 564" stroke="#4c3547" stroke-width="13"/><path d="M142 564 Q94 530 111 486 Q141 499 163 531Z" fill="url(#blade)" stroke="#806348" stroke-width="5"/></g>'''
    if w=='halberd':
        return '''<g><path d="M700 948 L638 110" stroke="#231e1b" stroke-width="27" stroke-linecap="round"/><path d="M700 948 L638 110" stroke="#9b7440" stroke-width="14"/><path d="M638 110 Q546 72 560 9 Q627 24 653 79 Q695 23 765 38 Q743 114 668 145 Q648 132 638 110Z" fill="url(#blade)" stroke="#344247" stroke-width="10"/><path d="M631 104 Q659 49 765 38 Q711 102 655 132Z" fill="#fff8dc" opacity=".68"/><path d="M600 160 Q644 192 691 156 L710 190 Q654 232 580 196Z" fill="url(#metal)" stroke="#5d4127" stroke-width="7"/><path d="M622 210 L663 218 L655 263 L613 251Z" fill="#9a2f2f"/></g>'''
    if w=='axes':
        return '''<g><path d="M145 916 L250 260 M653 925 L590 270" stroke="#251d19" stroke-width="23" stroke-linecap="round"/><path d="M145 916 L250 260 M653 925 L590 270" stroke="#b18b50" stroke-width="12"/><path d="M250 260 Q159 194 115 246 Q160 300 136 375 Q242 362 265 292Z" fill="url(#blade)" stroke="#3e4543" stroke-width="9"/><path d="M590 270 Q691 197 735 253 Q681 314 714 384 Q605 365 577 302Z" fill="url(#blade)" stroke="#3e4543" stroke-width="9"/><path d="M219 317 L280 335 M560 329 L623 342" stroke="url(#metal)" stroke-width="12"/></g>'''
    return '''<g><path d="M675 920 L630 150" stroke="#2a201b" stroke-width="23"/><path d="M675 920 L630 150" stroke="#a57b43" stroke-width="12"/><path d="M630 150 Q546 92 565 18 Q632 38 650 99 Q701 48 753 72 Q727 145 659 177Z" fill="url(#blade)" stroke="#39474b" stroke-width="8"/></g>'''

def cloak(h):
    k=h['kind']
    if k=='female':
        return '''<path d="M350 394 Q250 390 194 547 Q163 714 245 920 Q327 963 402 904 Q490 973 574 902 Q655 715 612 518 Q567 393 464 392Z" fill="url(#cape)" stroke="#3d2943" stroke-width="12"/><path d="M240 510 Q182 713 300 881 Q337 916 375 914 Q290 742 353 497Z" fill="url(#brocade)" opacity=".72"/><path d="M521 478 Q630 673 551 889 L506 918 Q563 680 470 515Z" fill="#251f34" opacity=".65"/>'''
    if k=='scholar':
        return '''<path d="M365 366 Q265 379 214 540 Q182 704 231 884 Q306 952 399 915 Q494 954 580 887 Q632 670 570 484 Q520 365 435 368Z" fill="url(#cape)" stroke="#253c3c" stroke-width="11"/><path d="M260 490 Q204 684 299 870 L352 902 Q303 690 379 470Z" fill="url(#brocade)" opacity=".7"/><path d="M515 461 Q617 670 537 875 L500 900 Q556 651 464 472Z" fill="#172d32" opacity=".55"/>'''
    if k=='brute':
        return '''<path d="M333 364 Q211 392 189 573 Q160 742 245 895 Q324 953 401 882 Q497 954 587 894 Q676 691 584 473 Q522 350 463 365Z" fill="url(#cape)" stroke="#1b1d22" stroke-width="16"/><path d="M230 522 Q197 712 309 882 L362 899 Q288 682 374 478Z" fill="url(#brocade)" opacity=".52"/><path d="M523 448 Q671 630 559 880 L513 908 Q593 666 459 486Z" fill="#171b25" opacity=".68"/>'''
    return '''<path d="M352 372 Q252 389 216 541 Q183 712 250 892 Q328 952 405 891 Q492 950 572 893 Q658 689 585 484 Q529 367 454 373Z" fill="url(#cape)" stroke="#232931" stroke-width="12"/><path d="M249 510 Q196 709 302 873 L354 902 Q297 700 377 481Z" fill="url(#brocade)" opacity=".6"/><path d="M524 459 Q644 658 551 884 L510 906 Q562 670 465 480Z" fill="#1a202a" opacity=".56"/>'''

def headgear(h):
    kind=h['helm']
    if kind=='plume': return '''<path d="M330 194 Q327 98 401 76 Q477 42 552 102 L566 213Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="10"/><path d="M403 92 Q435 5 481 15 Q472 88 443 125Z" fill="#f2eee0" stroke="#a6b7b2" stroke-width="6"/><path d="M429 87 Q481 14 493 22" fill="none" stroke="#fff" stroke-width="5"/><path d="M332 189 Q441 147 564 190 L572 223 Q451 184 333 224Z" fill="url(#metal)" stroke="#55452f" stroke-width="7"/>'''
    if kind=='scholar': return '''<path d="M333 167 L349 64 Q443 29 541 66 L556 168 L526 195 L360 195Z" fill="#283c3d" stroke="url(#metal)" stroke-width="9"/><path d="M350 76 Q443 45 536 77" fill="none" stroke="#e6d7ad" stroke-width="8"/><path d="M323 178 Q442 143 570 177 L562 216 Q439 185 330 220Z" fill="#496b62" stroke="url(#metal)" stroke-width="7"/><path d="M420 55 L443 12 L465 55" fill="none" stroke="#c3a36b" stroke-width="7"/>'''
    if kind=='veteran': return '''<path d="M322 175 Q336 81 425 63 Q518 59 565 150 L548 201 Q440 169 335 205Z" fill="#5b4938" stroke="url(#metal)" stroke-width="9"/><path d="M341 151 Q432 110 553 149" fill="none" stroke="#e4c17d" stroke-width="9"/><path d="M381 86 Q420 24 488 62 L469 112Z" fill="#b6b2a3"/><path d="M330 183 Q441 157 562 188 L559 222 Q440 199 330 226Z" fill="#344138" stroke="url(#metal)" stroke-width="7"/>'''
    if kind=='hairpin': return '''<path d="M330 189 Q326 99 407 74 Q503 55 557 158 L553 237 Q518 200 492 189 L354 226Z" fill="url(#hair)"/><path d="M365 130 Q402 46 477 67 Q525 78 550 125" fill="none" stroke="#d2a9cb" stroke-width="12"/><path d="M424 67 Q453 8 475 53 L462 118Z" fill="url(#metal)" stroke="#795d43" stroke-width="6"/><path d="M451 75 Q511 22 528 82 Q488 112 463 115Z" fill="#b65d91" stroke="#d8b678" stroke-width="5"/><circle cx="456" cy="97" r="12" fill="#f0d6a0" stroke="#a57e4b" stroke-width="4"/>'''
    if kind=='crown': return '''<path d="M322 177 L346 83 L389 126 L433 48 L476 124 L522 78 L560 182 L544 215 L340 217Z" fill="#34364a" stroke="url(#metal)" stroke-width="9"/><path d="M339 180 Q443 144 551 182" stroke="#d6b16a" stroke-width="10" fill="none"/><path d="M431 56 L447 15 L466 57" fill="none" stroke="#a74b53" stroke-width="7"/><path d="M420 163 L445 190 L470 163 L445 140Z" fill="#8a3440" stroke="#eed18b" stroke-width="5"/>'''
    if kind=='phoenix': return '''<path d="M328 184 Q343 82 432 61 Q521 71 560 177 L543 216 Q444 179 341 218Z" fill="#672f32" stroke="url(#metal)" stroke-width="9"/><path d="M394 99 Q360 32 407 13 Q445 47 433 113Z" fill="#c65b3e" stroke="#edcb83" stroke-width="5"/><path d="M474 99 Q505 22 540 55 Q531 105 490 124Z" fill="#e4a45f" stroke="#edcb83" stroke-width="5"/><path d="M344 176 Q445 144 554 179" fill="none" stroke="#f3d68b" stroke-width="9"/>'''
    if kind=='wings': return '''<path d="M321 182 Q325 83 430 64 Q536 58 567 175 L545 220 Q447 183 340 222Z" fill="#382e37" stroke="url(#metal)" stroke-width="10"/><path d="M344 122 Q244 12 278 4 Q361 24 412 103Z" fill="#9e352f" stroke="#d6b16c" stroke-width="8"/><path d="M490 101 Q544 12 596 24 Q582 101 536 147Z" fill="#8e302c" stroke="#d6b16c" stroke-width="8"/><path d="M337 178 Q445 139 562 180" fill="none" stroke="#e3bd73" stroke-width="10"/>'''
    if kind=='bare': return '''<path d="M341 193 Q329 94 417 67 Q507 47 557 151 L553 226 Q520 186 490 179 L351 228Z" fill="url(#hair)" stroke="#171b1c" stroke-width="8"/><path d="M358 109 Q430 43 522 113" stroke="#4e4b47" stroke-width="12" fill="none"/>'''
    return '''<path d="M327 181 Q334 89 420 62 Q510 56 559 169 L544 214 Q439 175 338 216Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="9"/><path d="M388 91 Q447 8 504 75 L478 128Z" fill="#dae6d6" stroke="#9caa93" stroke-width="6"/><path d="M337 178 Q445 144 559 181" fill="none" stroke="#e9d6a2" stroke-width="8"/>'''

def beard(h):
    b=h['beard']
    if b=='none': return ''
    if b=='long': return '''<path d="M364 299 Q389 288 411 307 Q441 326 461 304 Q488 280 523 302 Q536 351 507 407 Q475 467 446 510 Q418 451 386 405 Q354 352 364 299Z" fill="#202829" stroke="#0d171b" stroke-width="9"/><path d="M390 326 Q384 390 440 474 M421 326 Q416 407 448 490 M484 324 Q480 394 449 469" fill="none" stroke="#78877e" stroke-width="5" opacity=".75"/>'''
    if b=='grey': return '''<path d="M359 300 Q393 288 418 309 Q443 321 466 306 Q493 288 526 301 Q521 364 482 392 Q445 419 406 393 Q372 366 359 300Z" fill="#b8b9ae" stroke="#555a54" stroke-width="8"/><path d="M390 326 Q398 380 430 394 M464 324 Q456 375 432 394" stroke="#f4f0df" stroke-width="5" fill="none"/>'''
    if b=='wild': return '''<path d="M351 302 Q389 280 416 309 Q446 327 473 303 Q512 285 539 310 Q527 358 493 369 L511 421 L465 392 L447 466 L421 394 L385 420 L397 369 Q357 355 351 302Z" fill="#141a1b" stroke="#090f12" stroke-width="9"/><path d="M371 331 L396 360 M500 326 L474 361 M434 359 L440 429" stroke="#68736d" stroke-width="4" fill="none"/>'''
    if b=='short': return '''<path d="M369 302 Q397 291 418 309 Q443 321 466 306 Q494 290 518 302 Q512 334 479 345 Q446 354 427 336 Q398 349 378 330Z" fill="#251d20" stroke="#0d1216" stroke-width="6"/>'''
    return '''<path d="M371 302 Q400 289 421 308 Q444 320 468 306 Q495 292 520 304 Q511 333 484 342 Q451 352 430 335 Q400 347 378 328Z" fill="#38302c" stroke="#181719" stroke-width="6"/>'''

def body_svg(h):
    # silhouette choices preserve the same 800 x 1000 frame and common foot line
    female=h['kind']=='female'; brute=h['kind']=='brute'; scholar=h['kind']=='scholar'
    shoulders='''<path d="M329 414 Q355 366 427 380 L462 450 Q411 490 346 465 Q319 450 329 414Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="10"/><path d="M484 382 Q553 360 596 421 L591 469 Q528 496 477 447Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="10"/>'''
    if female:
        shoulders='''<path d="M344 411 Q375 380 430 398 L451 451 Q409 471 357 456Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="8"/><path d="M480 399 Q531 379 573 416 L557 461 Q510 478 473 448Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="8"/>'''
    if scholar:
        shoulders='''<path d="M351 404 Q390 377 432 394 L456 452 Q410 468 355 449Z" fill="url(#cloth)" stroke="url(#metal)" stroke-width="7"/><path d="M473 395 Q523 375 565 411 L555 454 Q507 471 467 447Z" fill="url(#cloth)" stroke="url(#metal)" stroke-width="7"/>'''
    chest='''<path d="M363 431 Q443 393 537 430 L578 627 Q451 682 326 625Z" fill="#26353b" stroke="url(#metal)" stroke-width="12"/><path d="M378 450 Q445 419 525 451 L552 602 Q451 642 350 600Z" fill="url(#armor)"/><path d="M378 450 Q445 419 525 451 L552 602 Q451 642 350 600Z" fill="url(#scales)" opacity=".78"/>'''
    if scholar or female:
        chest='''<path d="M360 420 Q436 387 531 425 L560 647 Q448 710 337 644Z" fill="url(#cloth)" stroke="url(#metal)" stroke-width="9"/><path d="M376 445 Q440 418 516 446 L535 622 Q448 667 356 622Z" fill="url(#brocade)" opacity=".55"/><path d="M386 435 L454 638 L499 446" fill="none" stroke="url(#metal)" stroke-width="8"/>'''
    if brute:
        chest='''<path d="M333 423 Q443 377 556 422 L602 638 Q454 699 302 638Z" fill="#302e2d" stroke="url(#metal)" stroke-width="14"/><path d="M351 448 Q445 402 538 448 L564 606 Q449 663 333 606Z" fill="url(#armor)"/><path d="M351 448 Q445 402 538 448 L564 606 Q449 663 333 606Z" fill="url(#scales)" opacity=".7"/>'''
    head= f'''<path d="M375 209 Q380 123 448 120 Q522 119 535 214 L520 296 Q501 345 452 358 Q401 345 384 295Z" fill="url(#skin)" stroke="#744b3b" stroke-width="9"/><path d="M383 240 Q395 310 448 332 Q493 326 524 244" fill="none" stroke="#f6d5b6" stroke-width="5" opacity=".5"/><path d="M384 239 Q355 229 362 270 Q368 297 390 297 M527 235 Q551 226 554 261 Q548 293 520 298" fill="url(#skin)" stroke="#744b3b" stroke-width="7"/>'''
    if brute:
        head='''<path d="M352 209 Q356 111 450 105 Q546 111 565 215 L544 300 Q509 357 451 362 Q383 350 362 293Z" fill="url(#skin)" stroke="#754a39" stroke-width="11"/><path d="M368 240 Q391 324 451 339 Q516 328 548 240" fill="none" stroke="#f5d1ad" stroke-width="5" opacity=".45"/>'''
    if female:
        head='''<path d="M375 209 Q381 119 450 119 Q523 124 535 218 L518 295 Q494 342 451 351 Q402 340 384 294Z" fill="url(#skin)" stroke="#8c5a4c" stroke-width="8"/><path d="M389 250 Q405 310 450 327 Q495 310 520 250" fill="none" stroke="#f9dfcf" stroke-width="6" opacity=".5"/>'''
    hair='''<path d="M370 235 Q341 112 419 82 Q498 47 552 137 Q579 192 541 260 L521 224 Q518 165 478 149 Q432 168 386 152 L390 255Z" fill="url(#hair)" stroke="#111820" stroke-width="10"/>'''
    if female:
        hair='''<path d="M369 248 Q332 98 417 70 Q506 42 556 143 Q580 210 542 300 Q529 364 573 456 Q520 434 511 350 L521 226 Q506 158 464 145 Q414 155 386 195 L391 288 Q380 386 318 435 Q354 333 369 248Z" fill="url(#hair)" stroke="#11131d" stroke-width="10"/><path d="M382 168 Q411 95 475 104" fill="none" stroke="#78627a" stroke-width="5" opacity=".7"/>'''
    if h['beard']=='grey': hair='''<path d="M365 235 Q344 125 416 87 Q503 47 552 142 Q575 201 542 260 L522 221 Q512 156 477 146 Q422 167 386 160Z" fill="#aeb0a9" stroke="#505653" stroke-width="10"/>'''
    if h['helm']=='bare': hair='''<path d="M362 240 Q338 143 417 105 Q497 67 552 147 Q573 203 541 262 L522 221 Q510 159 473 150 Q418 163 385 159Z" fill="url(#hair)" stroke="#111719" stroke-width="10"/>'''
    facial='''<path d="M402 249 Q426 224 447 244 M467 244 Q493 221 516 247" fill="none" stroke="#312720" stroke-width="10" stroke-linecap="round"/><path d="M402 270 Q424 281 446 269 Q425 254 402 270Z M468 269 Q491 281 515 269 Q492 254 468 269Z" fill="#f6e9d5" stroke="#3a2c25" stroke-width="4"/><ellipse cx="426" cy="270" rx="5" ry="7" fill="#191817"/><ellipse cx="491" cy="270" rx="5" ry="7" fill="#191817"/><path d="M454 267 L442 297 Q453 305 465 297" fill="none" stroke="#925f48" stroke-width="5"/><path d="M437 317 Q453 323 469 315" stroke="#7d443b" stroke-width="5" fill="none"/>'''
    if female: facial='''<path d="M402 248 Q425 230 445 246 M468 246 Q490 230 512 248" fill="none" stroke="#38262b" stroke-width="7" stroke-linecap="round"/><path d="M403 264 Q425 272 445 264 Q425 252 403 264Z M468 264 Q490 272 511 264 Q489 252 468 264Z" fill="#fcf1e4"/><ellipse cx="425" cy="264" rx="4" ry="6" fill="#2c1d21"/><ellipse cx="490" cy="264" rx="4" ry="6" fill="#2c1d21"/><path d="M453 265 L444 294 Q453 299 462 293" fill="none" stroke="#aa6a5c" stroke-width="4"/><path d="M436 315 Q452 322 469 315" fill="none" stroke="#9d5960" stroke-width="4"/>'''
    emblem='''<path d="M446 472 L474 503 L446 540 L418 503Z" fill="url(#metal)" stroke="#5d472e" stroke-width="5"/><path d="M446 485 L461 503 L446 522 L431 503Z" fill="{0}" stroke="#eee0ad" stroke-width="3"/>'''.format(h['accent'])
    if h['motif']=='dragon': emblem='''<path d="M416 477 Q455 452 479 480 Q493 503 468 514 Q451 521 433 508 Q456 493 451 482 Q432 482 425 502" fill="none" stroke="#e6e6d2" stroke-width="9"/><circle cx="475" cy="482" r="5" fill="#e5e2c7"/>'''
    if h['motif']=='eight': emblem='''<path d="M446 470 L482 506 L446 542 L410 506Z" fill="none" stroke="#d6c28a" stroke-width="6"/><path d="M446 480 L446 532 M420 506 L472 506 M428 488 L464 524 M464 488 L428 524" stroke="#d6c28a" stroke-width="4"/>'''
    if h['motif']=='sun': emblem='''<circle cx="446" cy="505" r="28" fill="none" stroke="#f2d38e" stroke-width="7"/><circle cx="446" cy="505" r="13" fill="#b84731" stroke="#f4d28a" stroke-width="4"/>'''
    if h['motif']=='moon': emblem='''<path d="M443 474 Q490 496 457 539 Q421 530 424 499 Q430 481 443 474Z" fill="#e2c4dc" stroke="#f5dfb8" stroke-width="5"/><circle cx="465" cy="496" r="6" fill="#f7e4b9"/>'''
    if h['motif']=='eagle': emblem='''<path d="M446 477 Q424 457 407 476 Q431 478 446 507 Q461 478 485 476 Q467 455 446 477Z" fill="#c3b4a2" stroke="#5b5262" stroke-width="4"/><path d="M446 499 L446 528" stroke="#f2d18b" stroke-width="6"/>'''
    if h['motif']=='flame': emblem='''<path d="M446 539 Q405 506 438 467 Q437 497 459 489 Q474 466 463 449 Q503 492 476 521Z" fill="#df7d45" stroke="#f3d08b" stroke-width="5"/>'''
    if h['motif']=='beast': emblem='''<path d="M411 478 L435 493 L446 475 L457 493 L481 478 L473 527 L446 543 L419 527Z" fill="#a13c33" stroke="#f0c87e" stroke-width="5"/><path d="M428 507 L438 514 M464 507 L454 514" stroke="#fff1c4" stroke-width="4"/>'''
    if h['motif']=='tiger': emblem='''<path d="M412 481 Q445 458 479 481 L468 526 L446 545 L424 526Z" fill="#a75d3a" stroke="#e3c27a" stroke-width="5"/><path d="M424 485 L442 500 L431 513 M468 485 L450 500 L461 513 M444 520 L448 537" stroke="#211e1b" stroke-width="7" fill="none"/>'''
    if h['motif']=='kylin': emblem='''<path d="M415 488 Q435 464 451 485 Q464 462 482 488 L468 523 L444 540 L422 522Z" fill="#c1d4c6" stroke="#f2d8a0" stroke-width="5"/><path d="M440 481 Q425 454 438 447 M456 481 Q470 455 483 449" stroke="#c5d6c4" stroke-width="6" fill="none"/>'''
    if female:
        legs='''<path d="M392 736 Q394 834 358 915 L311 947 Q375 978 433 941 L454 836Z" fill="url(#cloth)" stroke="#382b3d" stroke-width="9"/><path d="M471 739 Q490 833 507 915 L484 948 Q551 977 612 936 L567 868 L536 741Z" fill="url(#cloth)" stroke="#382b3d" stroke-width="9"/><path d="M300 936 Q371 914 439 943 L438 974 Q358 995 276 967Z M476 936 Q554 913 619 936 L645 969 Q557 995 474 970Z" fill="#37283c" stroke="url(#metal)" stroke-width="7"/>'''
    else:
        legs='''<path d="M354 735 Q365 828 330 901 L309 947 Q369 977 440 948 L464 838 L450 735Z" fill="#26343a" stroke="#151d22" stroke-width="12"/><path d="M481 736 Q502 828 510 900 L493 946 Q555 976 625 945 L603 877 L574 735Z" fill="#202d34" stroke="#151d22" stroke-width="12"/><path d="M330 829 Q385 849 458 828 L444 895 Q382 919 317 888Z M500 831 Q559 850 606 827 L627 890 Q566 916 502 889Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="7"/><path d="M306 921 Q374 904 444 932 L445 972 Q373 996 278 966Z M492 920 Q566 901 634 923 L654 966 Q565 996 480 969Z" fill="#171c22" stroke="url(#metal)" stroke-width="8"/>'''
    if brute:
        legs=legs.replace('354 735','327 735').replace('481 736','506 736')
    torso='''<path d="M358 374 Q441 344 533 381 Q625 427 635 565 L605 800 Q532 860 448 852 Q365 846 287 793 L300 565 Q304 429 358 374Z" fill="url(#cloth)" stroke="{dark}" stroke-width="15"/><path d="M338 474 Q385 499 416 532 L395 796 L313 765Z" fill="url(#brocade)" opacity=".55"/><path d="M533 440 Q606 489 612 587 L578 790 L529 806 L540 558Z" fill="{dark}" opacity=".6"/><path d="M445 381 L497 394 L548 816 Q482 851 410 817Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="7"/>'''.format(dark=h['dark'])
    if female: torso='''<path d="M363 376 Q450 347 530 386 Q584 433 593 583 L631 880 Q555 956 444 928 Q330 958 241 879 L300 578 Q309 430 363 376Z" fill="url(#cloth)" stroke="#49344b" stroke-width="12"/><path d="M348 467 Q398 500 420 532 L377 880 L274 857Z" fill="url(#brocade)" opacity=".6"/><path d="M519 444 Q578 524 561 691 L592 870 L522 890 L492 567Z" fill="#35283f" opacity=".45"/>'''
    if scholar: torso='''<path d="M361 373 Q443 341 529 378 Q600 436 618 614 L596 863 Q511 937 442 908 Q350 941 250 866 L296 577 Q306 429 361 373Z" fill="url(#cloth)" stroke="#293f40" stroke-width="12"/><path d="M348 466 Q392 497 416 533 L382 866 L285 839Z" fill="url(#brocade)" opacity=".65"/><path d="M518 438 Q585 520 568 704 L584 858 L519 879 L493 565Z" fill="#263d3e" opacity=".55"/>'''
    if brute:
        torso=torso.replace('358 374','333 374').replace('533 381','558 381')
    shoulders_layer=shoulders
    if female:
        arm='''<path d="M355 446 Q310 475 299 565 L332 651 Q363 660 386 626 L371 552 L416 500Z M536 448 Q587 469 620 554 L600 634 Q570 652 544 619 L559 548 L521 505Z" fill="url(#cloth)" stroke="#3a2b41" stroke-width="10"/><path d="M306 578 Q284 610 302 650 L346 666 L374 631 L346 586Z M604 576 Q631 604 638 642 L615 680 Q581 674 570 641Z" fill="url(#skin)" stroke="#855746" stroke-width="7"/>'''
    else:
        arm='''<path d="M350 448 Q303 470 286 568 L316 650 Q349 667 381 631 L366 553 L414 500Z M539 447 Q603 473 642 553 L618 640 Q590 658 557 623 L580 552 L526 504Z" fill="url(#armor)" stroke="{dark}" stroke-width="12"/><path d="M292 580 Q276 608 296 654 L343 672 L373 632 L340 587Z M620 575 Q651 600 666 641 L642 687 Q605 681 588 646Z" fill="url(#skin)" stroke="#744b3b" stroke-width="8"/><path d="M286 635 L355 648 L350 691 L300 678Z M595 646 L662 655 L651 698 L595 682Z" fill="url(#metal)" stroke="#5a4329" stroke-width="6"/>'''.format(dark=h['dark'])
    facehair=hair+head+headgear(h)+facial+beard(h)
    # robe / armor detailing
    detail=f'''<path d="M321 555 Q330 668 318 759 M598 553 Q615 677 588 776" fill="none" stroke="url(#metal)" stroke-width="8"/><path d="M333 566 Q342 669 331 747 M590 566 Q596 672 575 761" fill="none" stroke="{h['light']}" stroke-width="3"/><path d="M326 668 Q447 712 623 662 L632 714 Q464 771 318 716Z" fill="#1b252a" stroke="url(#metal)" stroke-width="9"/><path d="M422 690 L478 681 L494 736 L442 750Z" fill="url(#metal)" stroke="#5e4529" stroke-width="6"/>{emblem}<path d="M354 710 Q389 739 426 738 L410 826 Q370 806 337 780Z M540 717 Q587 711 614 690 L636 787 Q598 812 561 821Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="7"/><path d="M362 738 Q391 757 416 756 M560 750 Q591 746 620 725" stroke="{h['light']}" stroke-width="4"/>'''
    if scholar:
        detail += '''<path d="M390 459 Q443 503 497 459" fill="none" stroke="#e5d7b5" stroke-width="6"/><path d="M401 487 L449 629 L492 489" fill="none" stroke="#d7c28f" stroke-width="4"/>'''
    if female:
        detail += '''<path d="M355 627 Q444 670 551 624" fill="none" stroke="#f0d1df" stroke-width="6"/><path d="M386 693 Q442 735 518 697" fill="none" stroke="url(#metal)" stroke-width="4"/><circle cx="446" cy="684" r="10" fill="#8dc5c6" stroke="#ead1a0" stroke-width="4"/>'''
    rivets='''<g fill="#f5d995" stroke="#59452d" stroke-width="3"><circle cx="354" cy="424" r="6"/><circle cx="405" cy="409" r="6"/><circle cx="533" cy="413" r="6"/><circle cx="585" cy="431" r="6"/><circle cx="385" cy="480" r="5"/><circle cx="445" cy="468" r="5"/><circle cx="505" cy="478" r="5"/><circle cx="550" cy="496" r="5"/><circle cx="378" cy="528" r="5"/><circle cx="445" cy="520" r="5"/><circle cx="514" cy="532" r="5"/></g>'''
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1000" viewBox="0 0 800 1000">
<title>{h['name']} — {h['title']} original 2D full-body sprite</title>
<desc>Original hand-drawn vector character: {h['role']}. Unique costume silhouette, weapon, materials, insignia and facial features. Transparent background.</desc>
{defs(h)}
<ellipse cx="445" cy="960" rx="235" ry="25" fill="#0d1118" opacity=".25" filter="url(#shadow)"/>
{weapon(h)}
{cloak(h)}
{legs}
{torso}
{shoulders_layer}
{arm}
{chest}
<path d="M411 330 L410 402 Q449 427 490 399 L491 319Z" fill="url(#skin)" stroke="#744b3b" stroke-width="7"/>
{detail}
<path d="M365 222 Q367 120 449 112 Q529 118 540 223 L525 295 Q504 347 450 361 Q397 346 379 294Z" fill="url(#skin)" stroke="#704936" stroke-width="9"/>
{hair}
{headgear(h)}
{facial}
{beard(h)}
{rivets}
<path d="M412 269 Q418 292 433 303 M520 268 Q512 291 501 301" fill="none" stroke="#ffe0c0" stroke-width="4" opacity=".4"/>
<path d="M{635 if h['weapon'] in ('fan','bow','ribbon') else 315} 625 Q650 610 672 638 L680 671 Q662 699 634 688 L616 665Z" fill="url(#skin)" stroke="#744b3b" stroke-width="7"/>
<path d="M{635 if h['weapon'] in ('fan','bow','ribbon') else 315} 642 L{667 if h['weapon'] in ('fan','bow','ribbon') else 350} 654" stroke="url(#metal)" stroke-width="8"/>
</svg>'''

def portrait_svg(h):
    female=h['kind']=='female'; scholar=h['kind']=='scholar'; brute=h['kind']=='brute'
    if h['helm']=='hairpin': hat='''<path d="M114 218 Q120 84 247 74 Q380 62 404 208 L377 254 L144 254Z" fill="url(#hair)" stroke="#171723" stroke-width="9"/><path d="M264 92 Q309 14 335 83 L315 149Z" fill="url(#metal)" stroke="#6c5142" stroke-width="5"/><path d="M306 90 Q389 36 401 112 Q357 151 313 153Z" fill="#b65d91" stroke="#e1c78e" stroke-width="5"/><circle cx="322" cy="117" r="11" fill="#8bc2c8" stroke="#ebd3a0" stroke-width="5"/>'''
    elif h['helm']=='scholar': hat='''<path d="M142 206 L158 83 Q255 47 356 82 L371 208Z" fill="#283c3d" stroke="url(#metal)" stroke-width="10"/><path d="M155 94 Q254 61 360 94" stroke="#e6d7ad" stroke-width="8" fill="none"/><path d="M132 205 Q254 168 382 205 L372 242 L143 243Z" fill="#496b62" stroke="url(#metal)" stroke-width="7"/>'''
    elif h['helm']=='wings': hat='''<path d="M122 206 Q132 82 254 75 Q372 68 399 204 L377 246 L146 246Z" fill="#382e37" stroke="url(#metal)" stroke-width="10"/><path d="M142 147 Q43 33 78 25 Q169 51 210 131Z M305 130 Q378 24 436 44 Q419 133 364 172Z" fill="#9e352f" stroke="#d6b16c" stroke-width="7"/>'''
    elif h['helm']=='crown': hat='''<path d="M119 206 L143 103 L185 144 L251 56 L305 143 L352 93 L396 207Z" fill="#34364a" stroke="url(#metal)" stroke-width="10"/><path d="M140 198 Q256 158 379 198" stroke="#d6b16a" stroke-width="10" fill="none"/>'''
    elif h['helm']=='phoenix': hat='''<path d="M129 208 Q142 85 257 75 Q370 79 396 206 L374 243 L147 243Z" fill="#672f32" stroke="url(#metal)" stroke-width="10"/><path d="M198 111 Q160 28 212 18 Q260 60 237 128Z M302 113 Q347 25 390 59 Q375 116 329 144Z" fill="#d17a49" stroke="#edcb83" stroke-width="5"/>'''
    elif h['helm']=='bare': hat='''<path d="M124 221 Q115 99 238 76 Q365 61 402 194 L377 259 L147 255Z" fill="url(#hair)" stroke="#171b1c" stroke-width="9"/>'''
    elif h['helm']=='veteran': hat='''<path d="M124 211 Q138 84 259 73 Q370 79 402 205 L379 247 L147 247Z" fill="#5b4938" stroke="url(#metal)" stroke-width="9"/><path d="M144 157 Q261 116 383 157" fill="none" stroke="#e4c17d" stroke-width="9"/>'''
    elif h['helm']=='plume': hat='''<path d="M122 211 Q133 83 255 76 Q378 79 401 209 L377 247 L146 249Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="9"/><path d="M235 97 Q270 4 309 20 Q296 91 270 131Z" fill="#f2eee0" stroke="#a6b7b2" stroke-width="6"/>'''
    else: hat='''<path d="M123 209 Q137 88 258 74 Q374 72 400 207 L376 247 L146 247Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="9"/><path d="M216 106 Q254 20 318 86 L291 140Z" fill="#dae6d6" stroke="#9caa93" stroke-width="5"/>'''
    hair='''<path d="M111 254 Q93 99 241 67 Q374 45 420 190 L396 369 Q370 425 326 434 L146 410 Q100 355 111 254Z" fill="url(#hair)" stroke="#111820" stroke-width="12"/>'''
    if female: hair='''<path d="M106 271 Q86 75 243 62 Q389 53 418 215 L396 405 Q354 469 324 447 L361 263 Q344 161 264 150 Q172 143 143 240 L152 407 Q101 392 92 329Z" fill="url(#hair)" stroke="#11131d" stroke-width="12"/>'''
    face='''<path d="M153 199 Q165 110 255 110 Q347 111 357 206 L344 302 Q321 369 257 383 Q190 367 169 300Z" fill="url(#skin)" stroke="#744b3b" stroke-width="9"/><path d="M176 241 Q204 224 229 241 M281 241 Q307 224 333 241" fill="none" stroke="#302823" stroke-width="10" stroke-linecap="round"/><path d="M181 259 Q204 268 229 258 M281 258 Q306 268 330 259" stroke="#41312a" stroke-width="7" fill="none"/><ellipse cx="207" cy="258" rx="6" ry="9" fill="#191817"/><ellipse cx="305" cy="258" rx="6" ry="9" fill="#191817"/><path d="M255 260 L241 300 Q256 310 271 300" fill="none" stroke="#925f48" stroke-width="5"/>'''
    if female:
        face='''<path d="M153 199 Q165 108 255 110 Q346 115 357 206 L344 302 Q321 365 257 379 Q190 365 169 300Z" fill="url(#skin)" stroke="#8c5a4c" stroke-width="8"/><path d="M180 243 Q204 228 229 244 M282 244 Q307 228 332 243" fill="none" stroke="#38262b" stroke-width="7"/><path d="M184 259 Q207 267 229 259 M282 259 Q306 267 328 259" stroke="#4a3133" stroke-width="5" fill="none"/><ellipse cx="207" cy="258" rx="5" ry="7" fill="#2c1d21"/><ellipse cx="305" cy="258" rx="5" ry="7" fill="#2c1d21"/><path d="M255 260 L245 298 Q255 305 266 298" fill="none" stroke="#aa6a5c" stroke-width="4"/><path d="M231 324 Q255 333 280 324" fill="none" stroke="#9d5960" stroke-width="5"/>'''
    beardshape=''
    if h['beard']=='long': beardshape='''<path d="M176 295 Q213 289 235 311 Q258 329 277 309 Q306 285 336 302 Q327 383 257 426 Q203 390 176 295Z" fill="#202829" stroke="#0d171b" stroke-width="8"/><path d="M207 327 Q205 383 252 417 M284 323 Q294 377 260 418" stroke="#78877e" stroke-width="5" fill="none"/>'''
    elif h['beard']=='grey': beardshape='''<path d="M171 298 Q211 289 236 312 Q257 327 280 310 Q309 287 339 302 Q329 377 258 403 Q197 379 171 298Z" fill="#b8b9ae" stroke="#555a54" stroke-width="8"/>'''
    elif h['beard']=='wild': beardshape='''<path d="M164 297 Q211 278 237 311 Q258 329 281 307 Q315 285 345 303 L319 365 L337 401 L286 380 L258 431 L228 380 L177 403 L193 362Z" fill="#141a1b" stroke="#090f12" stroke-width="8"/>'''
    elif h['beard'] in ('short','fine'): beardshape='''<path d="M178 300 Q213 293 235 312 Q257 326 280 311 Q309 290 336 303 Q323 350 258 355 Q200 348 178 300Z" fill="#251d20" stroke="#0d1216" stroke-width="6"/>'''
    shoulders=f'''<path d="M88 497 Q129 415 217 401 L293 421 Q381 403 432 497 L420 584 L98 584Z" fill="url(#armor)" stroke="url(#metal)" stroke-width="12"/><path d="M124 500 Q249 437 391 500 L384 560 L127 560Z" fill="url(#scales)" opacity=".8"/>'''
    if female or scholar:
        shoulders=f'''<path d="M85 501 Q130 412 219 407 L294 422 Q376 409 434 501 L413 591 L104 591Z" fill="url(#cloth)" stroke="url(#metal)" stroke-width="10"/><path d="M113 503 Q257 440 405 503 L388 574 L126 574Z" fill="url(#brocade)" opacity=".55"/>'''
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
<title>{h['name']} portrait — {h['title']}</title>
{defs(h)}
<defs><radialGradient id="bg"><stop stop-color="{h['accent']}"/><stop offset=".55" stop-color="{h['mid']}"/><stop offset="1" stop-color="#151a22"/></radialGradient><clipPath id="round"><circle cx="256" cy="256" r="246"/></clipPath></defs>
<circle cx="256" cy="256" r="251" fill="#080d14" stroke="url(#metal)" stroke-width="8"/><g clip-path="url(#round)"><rect width="512" height="512" fill="url(#bg)"/><circle cx="256" cy="235" r="194" fill="none" stroke="{h['light']}" stroke-width="3" opacity=".35"/><path d="M15 425 Q256 360 497 425" stroke="{h['gold']}" stroke-width="3" fill="none" opacity=".5"/>
{shoulders}
<path d="M180 348 L176 425 Q255 469 338 425 L327 345Z" fill="url(#skin)"/>
{hair}
<path d="M153 199 Q165 110 255 110 Q347 111 357 206 L344 302 Q321 369 257 383 Q190 367 169 300Z" fill="url(#skin)" stroke="#744b3b" stroke-width="9"/>
{hat}
{face}
{beardshape}
<path d="M152 280 Q162 321 190 340 M359 279 Q351 322 323 340" stroke="#f8ddc1" stroke-width="4" fill="none" opacity=".45"/>
<path d="M0 442 Q256 405 512 442 L512 512 L0 512Z" fill="#111821" opacity=".78"/><path d="M0 443 Q256 408 512 443" stroke="url(#metal)" stroke-width="5" fill="none"/>
</g></svg>'''

for h in heroes:
    folder=h['slug'].replace('-', '_')
    body=body_svg(h)
    portrait=portrait_svg(h)
    source_dir=ROOT/'game-assets'/'sprites'/folder
    runtime_dir=ROOT/'app'/'src'/'main'/'assets'/'characters'/'2d'
    runtime_portraits=runtime_dir/'portraits'
    for target,content in [
        (source_dir/f'{folder}_idle.svg',body),
        (source_dir/f'{folder}_portrait.svg',portrait),
        (runtime_dir/f'{h["slug"]}.svg',body),
        (runtime_portraits/f'{h["slug"]}.svg',portrait),
        (OUT/f'{h["slug"]}.svg',body),
        (OUT/f'{h["slug"]}-portrait.svg',portrait),
    ]:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(content,encoding='utf-8')
print('Generated original 2D full-body and portrait SVGs for',len(heroes),'generals into game-assets/sprites and Android runtime assets.')
for h in heroes: print(h['id'],h['name'],h['slug'])
